package web;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import io.github.bonigarcia.wdm.WebDriverManager;
public class login {
public static void main(String[] args) throws InterruptedException {
	WebDriver driver;
	 WebDriverManager.chromedriver().setup();
     driver = new ChromeDriver();
     driver.manage().window().maximize();
     driver.get("https://www.saucedemo.com/");
     WebElement usernameField = driver.findElement(By.id("user-name"));
     usernameField.sendKeys("standard_user");
     // Locate the password input field and enter the password
     WebElement passwordField = driver.findElement(By.id("password"));
     passwordField.sendKeys("secret_sauce");
     // Locate the login button and click it
     WebElement loginButton = driver.findElement(By.id("login-button"));
     loginButton.click();
     // Optional: Add a short wait to observe the result (not recommended for production)
     try {
         Thread.sleep(3000);
     } catch (InterruptedException e) {
         e.printStackTrace();
     }
     // Add first item to cart
     driver.findElement(By.id("add-to-cart-sauce-labs-backpack")).click();
     driver.findElement(By.id("add-to-cart-sauce-labs-bike-light")).click();
     // Click on the cart icon
     driver.findElement(By.className("shopping_cart_link")).click();
     Thread.sleep(1000);
     // Click checkout button
     driver.findElement(By.id("checkout")).click();
     Thread.sleep(1000);
     // Fill in checkout info
     driver.findElement(By.id("first-name")).sendKeys("John");
     driver.findElement(By.id("last-name")).sendKeys("Doe");
     driver.findElement(By.id("postal-code")).sendKeys("12345");
     // Click continue
     driver.findElement(By.id("continue")).click();
     Thread.sleep(1000);
     // Click finish
     driver.findElement(By.id("finish")).click();
     Thread.sleep(2000);
     // Logout
     driver.findElement(By.id("react-burger-menu-btn")).click();
     Thread.sleep(1000);
     driver.findElement(By.id("logout_sidebar_link")).click();
     Thread.sleep(1000);
     driver.quit();
 }
}
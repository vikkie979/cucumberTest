package testrect;

import static org.testng.Assert.assertEquals;

import org.testng.annotations.Test;

import rectangle.rectangle;

public class RectangleTest {
  @Test
  public void testArea() {
      rectangle rect = new rectangle(5, 10);
      assertEquals(50.0, rect.getArea(), 0.001);
  }
  @Test
  public void testPerimeter() {
      rectangle rect = new rectangle(5, 10);
      assertEquals(30.0, rect.getPerimeter(), 0.001);
  }
}



package pom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class loginpage {
	WebDriver driver;
	private By Textinput = By.id("my-text-id");
	private By passwordField = By.name("my-password");
	private By Textarea=By.name("my-textarea");
	private By disabledinput=By.name("my-disabled");
	private By readonlyinput=By.name("my.readonly");
	private By mydatepicker=By.name("my-date");
	private By loginButton = By.id("submit");
	// Constructor
	public loginpage(WebDriver driver) {
		this.driver = driver;
	}
	// Page actions
	public void entertextinput(String username) {
		driver.findElement(Textinput).sendKeys(username);
	}
	public void enterPassword(String password) {
		driver.findElement(passwordField).sendKeys(password);
	}
	
	public void clickLogin() {
		driver.findElement(loginButton).click();
	}
	public void login(String user, String pass) {
		enterUsername(user);
		enterPassword(pass);
		clickLogin();
	}
}











}

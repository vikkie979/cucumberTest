package selenium;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import io.github.bonigarcia.wdm.WebDriverManager;

public class ElementAutomation {
    WebDriver driver;
    
    @BeforeTest
    public void setup() {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
    }
   
    public void automateElements() {
        driver.get("https://example.com");

        // Automate 8 elements
        WebElement element1 = driver.findElement(By.id("element1"));
        WebElement element2 = driver.findElement(By.name("element2"));
        WebElement element3 = driver.findElement(By.className("element3"));
        WebElement element4 = driver.findElement(By.tagName("element4"));
        WebElement element5 = driver.findElement(By.linkText("element5"));
        WebElement element6=driver.findElement(By.partialLinkText("element6"));
        WebElement element7 = driver.findElement(By.cssSelector(".element7"));
        WebElement element8 = driver.findElement(By.xpath("//element8"));

        // Perform actions on elements
        element1.click();
        element2.sendKeys("Test");
        element3.clear();
        element4.submit();
        element5.click();
        element6.click();
        element7.sendKeys("Test");
        element8.click();
    }

    @AfterTest
    public void teardown() {
    	if(driver!=null) {
    }
        driver.quit();
    }
}

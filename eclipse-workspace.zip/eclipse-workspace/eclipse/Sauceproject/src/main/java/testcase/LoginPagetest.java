package testcase;
import pom.LoginPage;
import testsetup.basetest;
public class LoginPagetest extends basetest {
    public static void main(String[] args) throws InterruptedException {
    	LoginPagetest test = new LoginPagetest();
        test.setup();
        test.driver.get("https://www.saucedemo.com");
        LoginPage loginPage = new LoginPage(test.driver);
        loginPage.login("standard_user","secret_sauce");
        
        String currentUrl = test.driver.getCurrentUrl();
        System.out.println("Login success. Navigated to: " + currentUrl);


        test.tearDown();
    }
}

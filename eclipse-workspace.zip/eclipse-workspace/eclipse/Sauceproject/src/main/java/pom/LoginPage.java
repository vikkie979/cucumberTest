package pom;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class LoginPage {
	WebDriver driver;
	 private By Username=By.id("user-name");
	 private By Password=By.id("password");
	 private By login=By.id("login-button");
	 private By addcart=By.id("add-to-cart-sauce-labs-backpack");
	 private By seecart=By.xpath("/html/body/div/div/div/div[1]/div[1]/div[3]/a");
	 
	 public LoginPage(WebDriver driver) {
		 this.driver=driver;
	 }
	 
		 
	    public void enterUsername(String username) {
			 driver.findElement(Username).sendKeys("standard_user");
		}
		public void enterPassword(String password) {
			driver.findElement(Password).sendKeys("secret_sauce");
		}
		public void login() {
			driver.findElement(login).click();
		
		}
		
		


		public void addcart() throws InterruptedException {
			driver.findElement(addcart).click();
			Thread.sleep(3000);
			
		}
		
		

public void login(String username, String password) throws InterruptedException {
        enterUsername(username);
        enterPassword(password);
        login();
        addcart();
       
    }

}


 



package jacococ;
import org.junit.Test;
import static org.junit.Assert.*;

public class clc {
	
	@Test
	public void testAdd() {
		calculator c=new calculator();
		assertEquals(5, c.add(2,3));
	}
	@Test
	public void tesySubtract() {
		calculator c =new calculator();
		assertEquals(1, c.subtract(3, 2));
		
		
	}

}

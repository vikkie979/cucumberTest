package pom;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.*;

import java.time.Duration;

public class SauceDemoFullTestSuite {
    WebDriver driver;

    @BeforeClass
    public void setup() {
        System.setProperty("webdriver.chrome.driver", "C://Users//LabsKraft//Downloads//chromedriver-win64//chromedriver-win64//chromedriver.exe");
        driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
        driver.manage().window().maximize();
    }

    @BeforeMethod
    public void goToLoginPage() {
        driver.get("https://www.saucedemo.com/");
    }

    // ========== LOGIN PAGE TESTS ==========

    @Test
    public void loginValidUser() {
        login("standard_user", "secret_sauce");
        Assert.assertTrue(driver.getCurrentUrl().contains("inventory.html"), "User should be logged in");
    }

    @Test
    public void loginLockedOutUser() {
        login("locked_out_user", "secret_sauce");
        WebElement error = driver.findElement(By.cssSelector("[data-test='error']"));
        Assert.assertTrue(error.isDisplayed());
        Assert.assertTrue(error.getText().toLowerCase().contains("locked out"));
    }

    @Test
    public void loginInvalidUser() {
        login("invalid_user", "secret_sauce");
        WebElement error = driver.findElement(By.cssSelector("[data-test='error']"));
        Assert.assertTrue(error.isDisplayed());
    }

    @Test
    public void loginEmptyCredentials() {
        driver.findElement(By.id("login-button")).click();
        WebElement error = driver.findElement(By.cssSelector("[data-test='error']"));
        Assert.assertTrue(error.isDisplayed());
    }

    // ========== PRODUCTS PAGE TESTS ==========

    @Test
    public void addToCartButtonFunctionality() {
        login("standard_user", "secret_sauce");
        WebElement addToCartBtn = driver.findElement(By.cssSelector("button[data-test='add-to-cart-sauce-labs-backpack']"));
        addToCartBtn.click();
        Assert.assertEquals(addToCartBtn.getText(), "Remove");
    }

    @Test
    public void removeButtonFunctionality() {
        login("standard_user", "secret_sauce");
        WebElement addToCartBtn = driver.findElement(By.cssSelector("button[data-test='add-to-cart-sauce-labs-backpack']"));
        addToCartBtn.click();  // add
        addToCartBtn.click();  // remove
        Assert.assertEquals(addToCartBtn.getText(), "Add to cart");
    }

    @Test
    public void addMultipleItemsToCart() {
        login("standard_user", "secret_sauce");
        driver.findElement(By.cssSelector("button[data-test='add-to-cart-sauce-labs-backpack']")).click();
        driver.findElement(By.cssSelector("button[data-test='add-to-cart-sauce-labs-bike-light']")).click();
        driver.findElement(By.cssSelector("button[data-test='add-to-cart-sauce-labs-bolt-t-shirt']")).click();

        WebElement cartBadge = driver.findElement(By.className("shopping_cart_badge"));
        Assert.assertEquals(cartBadge.getText(), "3");
    }

    // ========== CART PAGE TESTS ==========

    @Test
    public void removeItemFromCart() {
        login("standard_user", "secret_sauce");
        driver.findElement(By.cssSelector("button[data-test='add-to-cart-sauce-labs-backpack']")).click();
        driver.findElement(By.className("shopping_cart_link")).click();

        driver.findElement(By.cssSelector("button[data-test='remove-sauce-labs-backpack']")).click();

        Assert.assertTrue(driver.findElements(By.className("cart_item")).isEmpty());
    }

    @Test
    public void continueShoppingButton() {
        login("standard_user", "secret_sauce");
        driver.findElement(By.cssSelector("button[data-test='add-to-cart-sauce-labs-backpack']")).click();
        driver.findElement(By.className("shopping_cart_link")).click();

        driver.findElement(By.id("continue-shopping")).click();

        Assert.assertTrue(driver.getCurrentUrl().contains("inventory.html"));
    }

    // ========== CHECKOUT PAGE TESTS ==========

    @Test
    public void checkoutValidData() {
        login("standard_user", "secret_sauce");
        addProductAndGoToCheckout();

        driver.findElement(By.id("first-name")).sendKeys("John");
        driver.findElement(By.id("last-name")).sendKeys("Doe");
        driver.findElement(By.id("postal-code")).sendKeys("12345");
        driver.findElement(By.id("continue")).click();

        Assert.assertTrue(driver.getCurrentUrl().contains("checkout-step-two.html"));
    }

    @Test
    public void checkoutEmptyFirstName() {
        login("standard_user", "secret_sauce");
        addProductAndGoToCheckout();

        // Empty first name
        driver.findElement(By.id("last-name")).sendKeys("Doe");
        driver.findElement(By.id("postal-code")).sendKeys("12345");
        driver.findElement(By.id("continue")).click();

        WebElement error = driver.findElement(By.cssSelector("[data-test='error']"));
        Assert.assertTrue(error.isDisplayed());
    }

    @Test
    public void checkoutEmptyLastName() {
        login("standard_user", "secret_sauce");
        addProductAndGoToCheckout();

        driver.findElement(By.id("first-name")).sendKeys("John");
        // Empty last name
        driver.findElement(By.id("postal-code")).sendKeys("12345");
        driver.findElement(By.id("continue")).click();

        WebElement error = driver.findElement(By.cssSelector("[data-test='error']"));
        Assert.assertTrue(error.isDisplayed());
    }

    @Test
    public void checkoutEmptyPostalCode() {
        login("standard_user", "secret_sauce");
        addProductAndGoToCheckout();

        driver.findElement(By.id("first-name")).sendKeys("John");
        driver.findElement(By.id("last-name")).sendKeys("Doe");
        // Empty postal code
        driver.findElement(By.id("continue")).click();

        WebElement error = driver.findElement(By.cssSelector("[data-test='error']"));
        Assert.assertTrue(error.isDisplayed());
    }

    @Test
    public void checkoutInvalidPostalCode() {
        login("standard_user", "secret_sauce");
        addProductAndGoToCheckout();

        driver.findElement(By.id("first-name")).sendKeys("John");
        driver.findElement(By.id("last-name")).sendKeys("Doe");
        driver.findElement(By.id("postal-code")).sendKeys("!@#$%");
        driver.findElement(By.id("continue")).click();

        // The app may or may not validate postal code format strictly,
        // this test assumes it does show an error for invalid input
        WebElement error = driver.findElement(By.cssSelector("[data-test='error']"));
        Assert.assertTrue(error.isDisplayed());
    }

    // ========== CHECKOUT OVERVIEW PAGE ==========

    @Test
    public void finishButtonWorks() {
        login("standard_user", "secret_sauce");
        addProductAndGoToCheckout();

        driver.findElement(By.id("first-name")).sendKeys("John");
        driver.findElement(By.id("last-name")).sendKeys("Doe");
        driver.findElement(By.id("postal-code")).sendKeys("12345");
        driver.findElement(By.id("continue")).click();

        driver.findElement(By.id("finish")).click();

        Assert.assertTrue(driver.getCurrentUrl().contains("checkout-complete.html"));
    }

    @Test
    public void cannotFinishWithoutCheckout() {
        login("standard_user", "secret_sauce");

        // Try to access finish page directly (invalid flow)
        driver.get("https://www.saucedemo.com/checkout-complete.html");

        // Should redirect back or not allow finishing order
        Assert.assertFalse(driver.getCurrentUrl().contains("checkout-complete.html"));
    }

    // ======= Helper methods =======

    public void login(String username, String password) {
        driver.findElement(By.id("user-name")).sendKeys(username);
        driver.findElement(By.id("password")).sendKeys(password);
        driver.findElement(By.id("login-button")).click();
    }

    public void addProductAndGoToCheckout() {
        driver.findElement(By.cssSelector("button[data-test='add-to-cart-sauce-labs-backpack']")).click();
        driver.findElement(By.className("shopping_cart_link")).click();
        driver.findElement(By.id("checkout")).click();
    }

    @AfterClass
    public void teardown() {
        if (driver != null) {
            driver.quit();
        }
    }
}

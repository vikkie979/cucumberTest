package testcase;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.*;
import org.testng.asserts.SoftAssert;

import pom.CartPage;
import pom.CheckoutPage;
import pom.FinishPage;
import pom.LoginPage;
import pom.ProductsPage;

public class SauceDemoTest {
    WebDriver driver;
    LoginPage loginPage;
    ProductsPage productsPage;
    CartPage cartPage;
    CheckoutPage checkoutPage;
    FinishPage finishPage;

    @BeforeClass
    public void setup() {
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://www.saucedemo.com/");
        loginPage = new LoginPage(driver);
        productsPage = new ProductsPage(driver);
        cartPage = new CartPage(driver);
        checkoutPage = new CheckoutPage(driver);
        finishPage = new FinishPage(driver);
    }

    @Test
    public void completePurchaseFlow() throws InterruptedException {
        loginPage.login("standard_user", "secret_sauce");
        productsPage.addItemsToCart();
        productsPage.goToCart();
        cartPage.checkout();
        checkoutPage.fillDetails("John", "Doe", "560001");
        finishPage.finishOrder();
        finishPage.backHome();
        Thread.sleep(5000);
    }
    @Test
    public void testTextBoxInputtrue() throws InterruptedException {
        // Locate the text box by ID
        WebElement textBox = driver.findElement(By.name("my-text"));
        // Enter text
        String input = "TestNG Example";
        textBox.clear();
        textBox.sendKeys(input);
        // Get value and assert it
        String actualValue = textBox.getAttribute("value");
        Assert.assertEquals(actualValue, input, "Text box value doesn't match");
        Thread.sleep(5000);
    }
    @Test
    public void testTextBoxInputfalse() throws InterruptedException {
        // Locate the text box by ID
        WebElement textBox = driver.findElement(By.name("my-text"));
        // Enter text
        String input = "TestNG Example";
        textBox.clear();
        textBox.sendKeys("1234567");
        // Get value and assert it
        String actualValue = textBox.getAttribute("value");
        Assert.assertEquals(actualValue, input, "Text box value doesn't match");
        Thread.sleep(5000);

    }








    @AfterClass
    public void tearDown() {
        driver.quit();
    }
}

package testcase;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
public class Webform {
    WebDriver driver;
    // Locators
    private By firstNameField = By.id("firstName");
    private By lastNameField = By.id("lastName");
    private By emailField = By.id("userEmail");
    private By maleRadio = By.xpath("//*[@id=\"genterWrapper\"]/div[2]/div[1]/label");
    private By mobileField = By.id("userNumber");
    private By subjectsField = By.id("subjectsInput");
    private By hobbiesCheckbox = By.xpath("//*[@id=\"hobbiesWrapper\"]/div[2]/div[1]/label");
    private By currentAddressField = By.xpath("//*[@id=\"currentAddress\"]");
    private By submitButton = By.xpath("//*[@id=\"submit\"]");
    // Constructor
    public Webform(WebDriver driver) {
        this.driver = driver;
    }
    // Page actions
    public void enterFirstName(String fname) {
        driver.findElement(firstNameField).sendKeys(fname);
    }
    public void enterLastName(String lname) {
        driver.findElement(lastNameField).sendKeys(lname);
    }
    public void enterEmail(String email) {
        driver.findElement(emailField).sendKeys(email);
    }
    public void selectGenderMale() {
        driver.findElement(maleRadio).click();
    }
    public void enterMobile(String mobile) {
        driver.findElement(mobileField).sendKeys(mobile);
    }
    public void enterSubjects(String subject) {
       WebElement cc=driver.findElement(subjectsField);
        cc.sendKeys(subject);
        cc.sendKeys(Keys.ENTER);
    }
    public void selectHobbies() {
        driver.findElement(hobbiesCheckbox).click();
    }
    public void enterCurrentAddress(String address) {
        driver.findElement(currentAddressField).sendKeys(address);
    }
    public void clickSubmit() {
        driver.findElement(submitButton).click();
    }
    // Combined Action (optional)
    public void register(String fname, String lname, String email, String mobile, String subject, String address) {
        enterFirstName(fname);
        enterLastName(lname);
        enterEmail(email);
        selectGenderMale();
        enterMobile(mobile);
        enterSubjects(subject);
        selectHobbies();
        enterCurrentAddress(address);
        clickSubmit();
    }
	
}
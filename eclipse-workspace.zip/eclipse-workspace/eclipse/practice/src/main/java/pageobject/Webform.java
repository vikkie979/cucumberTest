package pageobject;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
public class Webform {
	WebDriver driver;
	//locator
	 private By Textinput=By.id("my-text-id");
	 private By Password=By.name("my-password");
	 private By Textarea=By.name("my-textarea");
	 private By Dropdown=By.name("my-select");
	 private By fileupload=By.name("my-file");
	 private By datepicker=By.name("my-date");
	 private By checkboxdata=By.name("my-datalist");
	 private By submit=By.cssSelector("button[type='submit']");
	 public Webform(WebDriver driver) {
		 this.driver=driver;
		
	 }
	// Page actions
		public void enterUsername(String username) {
			driver.findElement(Textinput).sendKeys(username);
		}
		public void enterPassword(String password) {
			driver.findElement(Password).sendKeys(password);
		}
		public void enterTextarea(String textarea2) {
			driver.findElement(Textarea).sendKeys(textarea2);
		}
		
		/*public void clickdropdown(String value) {
             driver.findElement(By.id("dropdown"));
              Select select = new Select(null);
       // or use selectByValue(value)
         }
		public void fileupload() {
			((Object) driver.findElement(fileupload)).sendKeys();
		}
    public void uploadFile(String filePath) {
        driver.findElement(fileupload).sendKeys(filePath);
		public void submit(String user, String pass,String textarea) {
			enterUsername(user);
			enterPassword(pass);
			enterTextarea(textarea);
			driver.findElement(submit).click();
		}*/
	
}
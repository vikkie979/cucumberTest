package testng;
import org.testng.annotations.Test;
public class grouptest {
    @Test(groups = {"smoke","Priority=2"})
    public void loginTest() {
        System.out.println("Smoke: Login Test");
    }
    @Test(groups = {"smoke", "regression","Priority=1"})
    public void searchTest() {
        System.out.println("Smoke + Regression: Search Test");
    }
    @Test(groups = {"regression","Priority=4"})
    public void addToCartTest() {
        System.out.println("Regression: Add to Cart Test");
    }
    @Test(groups = {"sanity","Priority=3"})
    public void profileUpdateTest() {
        System.out.println("Sanity: Profile Update Test");
    }
    @Test
    public void aboutPageTest() {
        System.out.println("No Group: About Page Test");
    }
}












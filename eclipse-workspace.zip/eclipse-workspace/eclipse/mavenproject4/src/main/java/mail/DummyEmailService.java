package mail;

import mail.mailservice;

public abstract class DummyEmailService implements mailservice {
	public void DummyEmailService(String message) {
		// TODO Auto-generated method stub
		
	}
}
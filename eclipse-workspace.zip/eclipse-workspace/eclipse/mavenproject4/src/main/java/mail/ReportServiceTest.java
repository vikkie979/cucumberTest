package mail;

import org.testng.Assert;

import puthusu.DummyEmailService;
import puthusu.mailservice;
import puthusu.reportservice;
import puthusu.test;

public class ReportServiceTest {
	@test
	public void testgeneratorreport() {
		mailservice dummyemail=new DummyEmailService();
		reportservice reportservice=new reportservice(dummyemail);
		String result=reportservice.generatereport();
		Assert.assertEquals(result,"report generate");

}
}

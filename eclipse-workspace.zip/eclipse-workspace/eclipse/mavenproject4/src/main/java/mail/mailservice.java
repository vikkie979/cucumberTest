package mail;

public interface mailservice {
	void sendEmail(String message);


}

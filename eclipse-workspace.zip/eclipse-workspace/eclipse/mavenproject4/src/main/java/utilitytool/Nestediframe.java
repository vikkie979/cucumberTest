package utilitytool;
	import org.openqa.selenium.By;
	import org.openqa.selenium.WebDriver;
	import org.openqa.selenium.WebElement;
	import org.openqa.selenium.chrome.ChromeDriver;
	import io.github.bonigarcia.wdm.WebDriverManager;
	public class Nestediframe {
	    public static void main(String[] args) {
	        WebDriverManager.chromedriver().setup();
	        WebDriver driver = new ChromeDriver();
	        try {
	            // 1. Navigate to the nested frames page
	            driver.get("https://the-internet.herokuapp.com/nested_frames");
	            driver.manage().window().maximize();
	            // 2. Switch to the top frame first
	            driver.switchTo().frame("frame-top");
	            // 3. Inside top frame, switch to the middle frame
	            driver.switchTo().frame("frame-middle");
	            // 4. Get and print text from middle frame
	            WebElement middleText = driver.findElement(By.id("content"));
	            System.out.println("Middle Frame Text: " + middleText.getText());
	            // 5. Go back to parent (frame-top), then to default content
	            driver.switchTo().parentFrame(); // frame-top
	            driver.switchTo().defaultContent(); // main page
	            // 6. Switch to bottom frame
	            driver.switchTo().frame("frame-bottom");
	            // 7. Get and print text from bottom frame
	            WebElement bottomText = driver.findElement(By.tagName("body"));
	            System.out.println("Bottom Frame Text: " + bottomText.getText());
	        } catch (Exception e) {
	            e.printStackTrace();
	        } finally {
	            // Close the browser
	            driver.quit();
	        }
	    }
	}



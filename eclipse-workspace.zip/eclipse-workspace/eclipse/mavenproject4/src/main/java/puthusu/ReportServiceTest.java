package puthusu;
import org.testng.annotations.Test;
import org.testng.Assert;

public class ReportServiceTest {
	@test
	public void testgeneratorreport() {
		mailservice dummyemail=new DummyEmailService();
		reportservice reportservice=new reportservice(dummyemail);
		String result=reportservice.generatereport();
		Assert.assertEquals(result,"report generate");
	}

}

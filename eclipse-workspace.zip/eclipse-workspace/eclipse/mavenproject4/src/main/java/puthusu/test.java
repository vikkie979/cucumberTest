package puthusu;

public @interface test {

}

package puthusu;

public interface mailservice {

}

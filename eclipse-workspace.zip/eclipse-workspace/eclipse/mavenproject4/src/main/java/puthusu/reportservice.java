package puthusu;

public class reportservice {
	private mailservice mailservice;
	 
	public reportservice(mailservice mailservice) {
		this.mailservice=	mailservice;
		}
	public String generatereport() {
		return "report generated";
	}

}

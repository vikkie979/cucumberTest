package puthusu;

public class DummyEmailService implements mailservice {
	public void sendEmail(String message) {
		// TODO Auto-generated method stub
		
	}
}

package constructor;

public class class2 {
	int eid;
	String ename;
	float esal;
	void disp() {
		System.out.println("Emp ID:" +eid);
		System.out.println("Emp name:" +ename);
		System.out.println("Emp esal:" +esal);
	}
	public static void main(String[]args) {
		class2 emp=new class2();
		emp.disp();
	}

}

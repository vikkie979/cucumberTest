package constructor;

public class class4 {
	int eid;
	String ename;
	float esal;
	class4(int eid,String ename,float esal){
		this.eid=eid;
		this.ename=ename;
		this.esal=esal;
	}
	void disp() {
		System.out.println("Emp ID:" +eid);
		System.out.println("Emp name:" +ename);
		System.out.println("Emp esal:" +esal);
	}
	public static void main(String[]args) {
		class4 emp =new class4(1001,"ramesh",10000);
		emp.disp();
		class4 emp1=new class4(1002,"suresh",20000);
		emp1.disp();
	}
		
		

}



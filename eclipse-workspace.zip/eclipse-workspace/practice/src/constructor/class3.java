package constructor;

public class class3 {
	int eid;
	String ename;
	float esal;
	class3(){
		eid=100;
		ename="vignesh";
		esal=100;
	}
	void disp() {
		System.out.println("Emp ID:" +eid);
		System.out.println("Emp name:" +ename);
		System.out.println("Emp esal:" +esal);
	}
	public static void main(String[]args) {
		class3 emp=new class3();
		emp.disp();
	}

}

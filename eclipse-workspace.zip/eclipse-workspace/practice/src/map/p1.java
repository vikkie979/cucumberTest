package map;
import java.util.Hashtable;
public class p1 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// Creating Hashtable
	    Hashtable<String,Integer> hashtable = new Hashtable<String,Integer>();
	    // Adding elements
	    hashtable.put("a",100);
	    hashtable.put("b",200);
	    hashtable.put("c",300);
	    hashtable.put("d",400);
	    //hashtable.put(null, 0); // error: no null allowed
	    // Displaying Hashtable
	    System.out.println(hashtable);
	}
}
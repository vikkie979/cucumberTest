package exception;

public class flly {
	public static void main(String[]args) {
		try {
			int[] myarray = {1,2,3};
			System.out.println(myarray[10]);
		}
		catch(Exception e) {
			System.out.println("wrong");
		}
		finally {
			System.out.println("finished");
		}
	}

}

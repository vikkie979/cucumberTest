package sample;
import java.util.Scanner;
public class samp {
	public static double age() {
		Scanner in=new Scanner(System.in);
		boolean valid=false;
		double input=0;
		while(!valid) {
			System.out.println("enter age <100");
			input=in.nextDouble();
			if(input>0&&input<100) {
				valid=true;
				System.out.println("this is correct age");
			}
			else {
				System.out.println("sorry invalid");
			}
		}
			return input;
		}
		public static void main(String[]args) {
			double a=age();
			System.out.println(a);
		}
	}



package Abstraction;

abstract class abs {
	abstract void printInfo();

}
class Employee extends abs{
	void printInfo() {
		String name="John";
		int age=21;
		float salary=222.2f;
		System.out.println(name);
		System.out.println(age);
		System.out.println(salary);
		
	}
}
class abs1{
	public static void main(String[] args) {
		abs s=new Employee();
		s.printInfo();
	}
}

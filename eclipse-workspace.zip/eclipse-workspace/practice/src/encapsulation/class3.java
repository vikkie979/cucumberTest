package encapsulation;

public class class3 {
	private int year;
	private String model;
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	public String getModel() {
		return model;
	}
  public class3(int year,String model) {
	  super();
	  this.year=year;
	  this.model=model;
  }
	

}

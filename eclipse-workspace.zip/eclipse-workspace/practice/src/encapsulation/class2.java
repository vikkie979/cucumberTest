package encapsulation;

public class class2 {
	public static void main(String[]args) {
		class1 person=new class1();
		person.setName("John");
		person.setAge(30);
		System.out.println("Name  "+person.getName());
		System.out.println("age   "+person.getAge());
	}

}

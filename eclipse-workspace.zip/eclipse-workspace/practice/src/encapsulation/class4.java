package encapsulation;

public class class4 {
	public static void main(String[]args) {
		class3 pt=new class3(2000,"tota");
		System.out.println(pt.getModel());
		System.out.println(pt.getYear());
		
	}

}

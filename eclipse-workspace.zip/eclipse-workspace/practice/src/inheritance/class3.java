package inheritance;
class q{
	q(){
		System.out.println("parent 0 arg const");
	}
}

public class class3 extends q {
	class3(){
		this(10);
		System.out.println("child 0 arg const");
	}
	class3(int a){
		super();
		System.out.println("child 1 arg");
	}
public static void main(String[]args) {
	new class3();
}

}

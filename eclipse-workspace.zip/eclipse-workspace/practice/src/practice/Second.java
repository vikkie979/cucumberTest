package practice;

public class Second {
	int a=10;
	int b=20;
	int c=30;
	int d=40;
	
	public static void main(String[] args) {
		Second t=new Second();
		System.out.println(t.a);
		System.out.println(t.b);
		t.m1();
	}
	void m1() {
		System.out.println(c);
		System.out.println(d);
	}
	

}

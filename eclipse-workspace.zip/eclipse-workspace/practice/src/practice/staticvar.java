package practice;

public class staticvar {
	static int a=1000;
	static int b=2000;
	public static void main(String[] args) {
		System.out.println(staticvar.a);
		System.out.println(staticvar.b);
		staticvar t=new staticvar();
		t.m1();
}
	void m1() {
		System.out.println(staticvar.a);
		System.out.println(staticvar.b);
	}
}



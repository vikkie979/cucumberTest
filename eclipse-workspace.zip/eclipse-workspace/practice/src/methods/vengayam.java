package methods;

public class vengayam {
	void m1(int a,char ch) {
		System.out.println("m1 method");
		System.out.println(a);
		System.out.println(ch);
	}
	static void m2(String str,double d) {
		System.out.println("m2 method");
		System.out.println(str);
		System.out.println(d);
		
	}
	public static void main(String args[]) {
		vengayam t=new vengayam();
		t.m1(10,'r');
		t.m2("vicky", 10.5);
	}

}

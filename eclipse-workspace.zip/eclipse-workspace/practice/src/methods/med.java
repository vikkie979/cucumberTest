package methods;

public class med {
	void m1() {
		System.out.println("m1 method");
	}
	static void m2() {
		System.out.println("m2 method");
	}
	
	public static void main(String[] args) {
		med t=new med();
		t.m1();
		med.m2();
	}

}

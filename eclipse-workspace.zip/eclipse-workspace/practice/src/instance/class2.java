package instance;

public class class2 {
	class2(){
		System.out.println("0 arg const");
	}
	class2(int a){
		System.out.println("1 arg const");
	}
	{
		System.out.println("instance block 1");
	}
	public static void main(String args[]) {
		new class2();
		new class2(10);
	}

}

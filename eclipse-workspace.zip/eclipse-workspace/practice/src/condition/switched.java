package condition;

public class switched {
	public static void main(String[] args) {
		int i=1;
		switch(i++) {
		case 1:{
				System.out.println(" hi team");
				break;
			}
		case 2:{
			System.out.println(" hola team");
			break;
		}
		default:{
			System.out.println("bye");
		}
		}
	}

}

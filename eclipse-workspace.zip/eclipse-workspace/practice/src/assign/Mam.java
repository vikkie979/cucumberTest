package assign;
import java.util.ArrayList;
public class Mam{
   public static void main(String[] args){
     int sqfeet=1500;
     int pricepersqfeet=5000;
     double baseprice=sqfeet*pricepersqfeet;
     double regtax=0.08*baseprice;
     double gst=0.03*baseprice;
     double total=baseprice+regtax+gst;
     ArrayList<String>steps=new ArrayList<>();
     steps.add("FLATAREA:"+sqfeet+"sq feet");
     steps.add("PRICEPERSQFEET:RS"+pricepersqfeet);
     steps.add("BASEPRICE:RS"+baseprice);
     steps.add("REGTAX:RS"+regtax);
     steps.add("GST(3%):RS"+gst);
     steps.add("total price to pay:RS"+total);
     System.out.println("===Real Estate===");
     for(String s:steps){
       System.out.println(s);
    }
   }
  }
     
package assign;
import java.util.*;
class Mant{
    String name, surname, phone, email, place;
public Mant(String name, String surname, String phone, String email, String place){
      this.name=name;
      this.surname=surname;
      this.phone=phone;
      this.email=email;
      this.place=place;
}
}
public class Man{
  public static void main(String[] args){
     List<Mant>list=new LinkedList<>();
      Mant p1=new Mant("Vicky","S","9344655243","s@gmail.com","chennai");
      Mant p2=new Mant("Vignesh","S","9344653663","st@gmail.com","madurai");
      Mant p3=new Mant("vikeshwaran","S","9346735243","svt@gmail.com","delhi");
      list.add(p1);
      list.add(p2);
      list.add(p3);
      System.out.println("===Telephone Directory===");
      for(Mant p:list){
       System.out.println(p.name+""+p.surname+"|"+p.phone+"|"+p.email+"|"+p.place);
   }
  }
}